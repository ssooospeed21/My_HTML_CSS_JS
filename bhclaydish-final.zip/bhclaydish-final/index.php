<?php
session_start();
require 'php/db.php';

$stmt = $pdo->query("SELECT * FROM products LIMIT 4");
$popularProducts = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clay Dishes - Главная</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css"/>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include 'php/header.php'; ?>

<section class="hero-section text-center text-light bg-dark py-5">
    <div class="container">
        <h1 class="display-4">Clay Dishes</h1>
        <p class="lead">Керамическая посуда ручной работы</p>
        <a href="magazin.php" class="btn btn-primary btn-lg">Перейти в каталог</a>
    </div>
</section>

<section class="features-section py-5">
    <div class="container text-center">
        <h2 class="mb-4">Почему стоит выбрать нас?</h2>
        <div class="row">
            <div class="col-md-4">
                <div class="feature-card p-4 border rounded shadow-sm">
                    <h5 class="mb-3">Ручная работа</h5>
                    <p>Каждое изделие уникально, создано с душой и вниманием к деталям.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feature-card p-4 border rounded shadow-sm">
                    <h5 class="mb-3">Экологичность</h5>
                    <p>Мы используем только экологически чистые материалы.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feature-card p-4 border rounded shadow-sm">
                    <h5 class="mb-3">Доставка по всей стране</h5>
                    <p>Мы доставляем вашу посуду в любую точку страны быстро и надежно.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="hero-section text-center text-light bg-dark py-5">
    <div class="container">
        <!-- Слайдер акций -->
        <div class="promotions-slider mb-4">
            <?php
            $currentDate = date('Y-m-d');
            $promotions = $pdo->query("
                SELECT p.* 
                FROM promotions p
                WHERE p.start_date <= '$currentDate' AND p.end_date >= '$currentDate' AND p.is_active = 1
                ORDER BY p.discount_percent DESC
                LIMIT 5
            ")->fetchAll();

            if ($promotions):
                foreach ($promotions as $promotion):
                    // Получаем все товары из акции
                    $products = $pdo->prepare("
                        SELECT pr.id, pr.name, pr.description, pr.price, pr.image, pr.stock 
                        FROM products pr
                        JOIN promotion_products pp ON pr.id = pp.product_id
                        WHERE pp.promotion_id = ?
                    ");
                    $products->execute([$promotion['id']]);
                    $products = $products->fetchAll();

                    // Проверяем, есть ли у авторизованного пользователя товары из акции в корзине
                    $userHasProductInCart = false;
                    $productInCart = null;

                    if (isset($_SESSION['user_id']) && !empty($products)) {
                        $userId = (int)$_SESSION['user_id'];
                        $productIds = array_column($products, 'id');
                        $placeholders = implode(',', array_fill(0, count($productIds), '?'));

                        $stmt = $pdo->prepare("
                            SELECT c.product_id as id, p.name, p.description, p.price, p.image, p.stock
                            FROM cart c
                            JOIN products p ON c.product_id = p.id
                            WHERE c.user_id = ? AND c.product_id IN ($placeholders)
                            LIMIT 1
                        ");

                        $params = array_merge([$userId], $productIds);
                        $stmt->execute($params);
                        $productInCart = $stmt->fetch();

                        $userHasProductInCart = (bool)$productInCart;
                    }

                    // Выбираем товар для показа
                    $productToShow = null;
                    $message = '';

                    if ($userHasProductInCart && $productInCart) {
                        $productToShow = $productInCart;
                        $message = 'Закажите его прямо сейчас!';
                    } elseif (!empty($products)) {
                        $productToShow = $products[array_rand($products)];
                        if (isset($_SESSION['user_id'])) {
                            $message = 'Самое время посмотреть на что-то новое!';
                        }
                    }
                    ?>
                    <div class="promotion-slide">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <?php if (!empty($promotion['image'])): ?>
                                    <img src="<?php echo htmlspecialchars($promotion['image']); ?>" class="img-fluid rounded" alt="<?php echo htmlspecialchars($promotion['title']); ?>">
                                <?php elseif (!empty($productToShow['image'])): ?>
                                    <img src="<?php echo htmlspecialchars($productToShow['image']); ?>" class="img-fluid rounded" alt="<?php echo htmlspecialchars($promotion['title']); ?>">
                                <?php else: ?>
                                    <img src="img/default-promo.jpg" class="img-fluid rounded" alt="Специальные предложения">
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <h2 class="text-warning">Акция: <?php echo htmlspecialchars($promotion['title']); ?></h2>
                                <p class="lead"><?php echo htmlspecialchars($promotion['description']); ?></p>
                                <div class="discount-badge mb-3">
                                    <span class="badge bg-danger fs-3">-<?php echo htmlspecialchars($promotion['discount_percent']); ?>%</span>
                                </div>

                                <?php if (!empty($products) && !empty($productToShow)): ?>
                                    <div class="product-info">
                                        <h4><?php echo htmlspecialchars($productToShow['name']); ?></h4>
                                        <?php if (!empty($productToShow['description'])): ?>
                                            <p class="card-text"><?php echo htmlspecialchars(mb_strimwidth($productToShow['description'], 0, 100, '...')); ?></p>
                                        <?php endif; ?>
                                        <p class="price">
                                            <span class="text-decoration-line-through text-muted me-2"><?php echo number_format($productToShow['price'], 2, '.', ' '); ?> руб.</span>
                                            <span class="fw-bold fs-4 text-warning"><?php echo number_format($productToShow['price'] * (1 - $promotion['discount_percent'] / 100), 2, '.', ' '); ?> руб.</span>
                                        </p>
                                        <?php if (!empty($message)): ?>
                                            <p class="promo-message text-info"><?php echo $message; ?></p>
                                        <?php endif; ?>
                                        <a href="/product.php?id=<?php echo (int)$productToShow['id']; ?>" class="btn btn-primary btn-lg">Подробнее</a>
                                    </div>
                                <?php else: ?>
                                    <p>В этой акции пока нет товаров</p>
                                    <a href="/magazin.php" class="btn btn-primary btn-lg">Перейти в каталог</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php
                endforeach;
            else:
                ?>
                <div class="promotion-slide">
                    <div class="row align-items-center">
                        <div class="col-md-6">
                            <img src="img/default-promo.jpg" class="img-fluid rounded" alt="Специальные предложения">
                        </div>
                        <div class="col-md-6">
                            <h2>Специальные предложения</h2>
                            <p class="lead">Скоро здесь появятся новые акции!</p>
                            <a href="/magazin.php" class="btn btn-primary btn-lg">Перейти в каталог</a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- тут сделать вывод акций как в каталоге -->

<section class="popular-products-section py-5 bg-light">
    <div class="container">
        <h2 class="text-center mb-4">Популярные товары</h2>
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
            <?php foreach ($popularProducts as $product): ?>
                <div class="col">
                    <div class="card h-100">
                        <img src="<?php echo htmlspecialchars($product['image']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($product['name']); ?>">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title"><?php echo htmlspecialchars($product['name']); ?></h5>
                            <p class="card-text"><?php echo htmlspecialchars($product['description']); ?></p>
                            <p class="fw-bold mt-auto"><?php echo htmlspecialchars($product['price']); ?> руб.</p>
                            <a href="product.php?id=<?php echo $product['id']; ?>" class="btn btn-primary mt-2">Подробнее</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>


<section class="about-section text-center py-5">
    <div class="container">
        <h2 class="mb-4">О нас</h2>
        <p>Clay Dishes — это онлайн-магазин керамической посуды, где собраны самые лучшие изделия ручной работы. Мы создаём тепло, уют и атмосферу благополучия в вашем доме.</p>
    </div>
</section>

<?php include 'php/footer.php'; ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
<script src="js/main.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const toggle = document.querySelector(".navbar-toggler");
        const menu = document.querySelector("#navbarNavDropdown");
        if (toggle && menu) {
            toggle.addEventListener("click", function () {
                const bsCollapse = new bootstrap.Collapse(menu, {
                    toggle: false
                });
                if (menu.classList.contains("show")) {
                    bsCollapse.hide();
                } else {
                    bsCollapse.show();
                }
            });
        }
    });
</script>

</body>
</html>
