-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Ноя 29 2024 г., 00:31
-- Версия сервера: 8.0.30
-- Версия PHP: 8.0.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `clay_dishes`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cart`
--

CREATE TABLE `cart` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity` int DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `comments`
--

CREATE TABLE `comments` (
  `id` int NOT NULL,
  `product_id` int NOT NULL,
  `user_id` int NOT NULL,
  `comment` text NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `favorites`
--

CREATE TABLE `favorites` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `product_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `favorites`
--

INSERT INTO `favorites` (`id`, `user_id`, `product_id`) VALUES
(4, 2, 1),
(7, 3, 2),
(6, 3, 30);

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `status` enum('pending','completed','canceled') COLLATE utf8mb4_general_ci DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `total`, `status`, `created_at`) VALUES
(4, 3, '12000.00', 'pending', '2024-11-28 21:26:50');

-- --------------------------------------------------------

--
-- Структура таблицы `order_items`
--

CREATE TABLE `order_items` (
  `id` int NOT NULL,
  `order_id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity` int NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `price`) VALUES
(6, 4, 30, 1, '12000.00');

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

CREATE TABLE `products` (
  `id` int NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `stock` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `image`, `stock`) VALUES
(1, 'Подарочный набор \"Hygge\"', 'Подарочный набор \"Hygge Huiagi\" для настоящих мужиков', '5000.01', 'img/p1.png', 60),
(2, 'Набор тарелок \"Leviosa\"', 'Набор тарелок \"Leviosa\"', '5550.00', 'img/p2.png', 0),
(3, 'Подарочный набор \"Lolito\"', 'Подарочный набор \"Lolito\"', '8990.00', 'img/p3.png', 0),
(4, 'Подарочный набор \"Star\"', 'Подарочный набор \"Star\"', '7890.00', 'img/p4.png', 1000),
(5, 'Набор посуды \"Lolito\"', 'Набор посуды \"Lolito\"', '14990.00', 'img/p5.png', 100),
(6, 'Подарочный набор \"Respira\"', 'Подарочный набор \"Respira\"', '5990.00', 'img/p6.png', 0),
(7, 'Подарочный набор \"Leviosa\"', 'Подарочный набор \"Leviosa\"', '28890.00', 'img/p7.png', 0),
(8, 'Набор посуды', 'Набор посуды', '5990.00', 'img/p8.png', 0),
(9, 'Тарелка \"Green\"', 'Тарелка \"Green\"', '890.00', 'img/t1.png', 0),
(10, 'Подарочный набор \"Hyg\"', 'Подарочный набор \"Hyg\"', '30990.00', 'img/p9.png', 0),
(11, 'Набор из 3 тарелок \"Rosa\"', 'Набор из 3 тарелок \"Rosa\"', '2750.00', 'img/t3.png', 0),
(12, 'Подарочный набор \"Star\"', 'Подарочный набор \"Star\"', '1190.00', 'img/t4.png', 0),
(13, 'Пиала \"Stars\"', 'Пиала \"Stars\"', '1350.00', 'img/t5.png', 0),
(14, 'Набор посуды \"Rewoo\"', 'Набор посуды \"Rewoo\"', '4500.00', 'img/t6.png', 0),
(15, 'Набор из 7 глубоких тарелок', 'Набор из 7 глубоких тарелок', '4900.00', 'img/t7.png', 0),
(16, 'Набор из 12 тарелок', 'Набор из 12 тарелок', '9950.00', 'img/t8.png', 0),
(17, 'Набор из 2 кружек \"love\"', 'Набор из 2 кружек \"love\"', '2490.00', 'img/k1.png', 0),
(18, 'Набор из 4 кружек \"Home\"', 'Набор из 4 кружек \"Home\"', '3990.00', 'img/k2.png', 0),
(19, 'Кружка \"Trix\"', 'Кружка \"Trix\"', '990.00', 'img/k3.png', 0),
(20, 'Кружка \"Kora\"', 'Кружка \"Kora\"', '1200.00', 'img/k4.png', 0),
(21, 'Набор из 2 кружек \"Sofa\"', 'Набор из 2 кружек \"Sofa\"', '1490.00', 'img/k5.png', 0),
(22, 'Набор из 2 кружек \"Blue\"', 'Набор из 2 кружек \"Blue\"', '1890.00', 'img/k6.png', 0),
(23, 'Кружка \"Kaktus\"', 'Кружка \"Kaktus\"', '1190.00', 'img/k7.png', 0),
(24, 'Кружка \"bool\"', 'Кружка \"bool\"', '9950.00', 'img/k8.png', 0),
(26, 'Набор посуды \"Sea\"', 'Набор посуды \"Sea\"', '7000.00', 'img/sale2.png', 0),
(27, 'Набор посуды \"Elle\"', 'Набор посуды \"Elle\"', '9000.00', 'img/sale3.png', 0),
(28, 'Лимонница \"Woow\"', 'Лимонница \"Woow\"', '5550.00', 'img/sale4.png', 998),
(29, 'Чайный набор \"Cyma\"', 'Армуды – традиционные стаканы грушевидной формы для подачи чая в Азербайджане, Турции и многих других восточных странах. Кроме эстетических преимуществ армуды имеют и теплофизические. В верхней части стакана чай быстрее остывает, а в нижней дольше хранится тепло за счет узкой \"талии\" стакана. Имея такую специальную форму армуды обеспечивают идеальную температуру употребления напитка. Набор состоит из 6 стаканов и 6 блюдец. Изготовлен из качественного стекла. Прекрасно подойдет для подачи чая гостям, так и для ежедневного использования. \r\n\r\nОбъем стаканов - 120 мл;\r\nДиаметр блюдца - 14,5 см', '10999.00', 'img/chaiphoto.jpg', 200),
(30, 'Чайный набор \"Cucri\"', 'Набор состоит из 6 стаканов и 6 блюдец. Изготовлен из качественного стекла. Прекрасно подойдет для подачи чая гостям, так и для ежедневного использования. \r\n\r\nОбъем стаканов - 120 мл;\r\nДиаметр блюдца - 14,5 см', '12000.00', 'img/large_fXLpmbioEyI.jpg', 298),
(31, 'набор \"Cucri\"', 'tguvwnhlukhwlcuwhnchlui4htnwuilcnhtslhrultlvukhi', '120000.00', 'img/1000_F_621007105_CUEghVzGrLinTvXGaSuQFIZCFNBYzlHB.jpg', 9);

-- --------------------------------------------------------

--
-- Структура таблицы `reviews`
--

CREATE TABLE `reviews` (
  `id` int NOT NULL,
  `product_id` int NOT NULL,
  `user_id` int NOT NULL,
  `comment` text COLLATE utf8mb4_general_ci NOT NULL,
  `rating` tinyint NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ;

--
-- Дамп данных таблицы `reviews`
--

INSERT INTO `reviews` (`id`, `product_id`, `user_id`, `comment`, `rating`, `created_at`) VALUES
(11, 1, 3, 'ksvhklv', 5, '2024-11-28 19:49:13');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `is_admin` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `is_admin`, `created_at`) VALUES
(1, 'admin', '$2y$10$dtbKolfRwhG0gVURFvpHS.kMhjyuY/zVni/yDAbgVhxmQDrWqysEa', 'admin@admin.com', 0, '2024-11-13 17:38:13'),
(2, 'suomi', '$2y$10$Oj5kjKm3iSpR.YjTfINXkOBsNQF6UZ8ZwbNUpTtsBI5YP9sG/Omjm', 'suomi@suomi.com', 1, '2024-11-28 15:40:12'),
(3, 'artem', '$2y$10$ZtEdBUXPvaYnIZmL08Eb7OuyUYEVz15Wmc2T1os/rZpmczrak8qh.', 'qwewra@gmail.com', 0, '2024-11-28 19:48:46');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Индексы таблицы `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `favorites`
--
ALTER TABLE `favorites`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`,`product_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT для таблицы `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `favorites`
--
ALTER TABLE `favorites`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT для таблицы `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `favorites`
--
ALTER TABLE `favorites`
  ADD CONSTRAINT `favorites_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `favorites_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
