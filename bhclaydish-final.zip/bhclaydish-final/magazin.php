<?php
session_start();
require 'php/db.php';

$searchQuery = '';
if (isset($_GET['search'])) {
    $searchQuery = trim($_GET['search']);
    $stmt = $pdo->prepare("SELECT * FROM products WHERE name LIKE :search");
    $stmt->execute(['search' => '%' . $searchQuery . '%']);
} else {
    $stmt = $pdo->query("SELECT * FROM products");
}
$products = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Каталог товаров</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include 'php/header.php'; ?>

<section class="catalog">
    <div class="wrapper">
        <h1 class="text-center my-4">Каталог товаров</h1>

        <!-- Строка поиска -->
        <!-- вот тут сделать помимо кнопки поиска ещё кнопку смены отображения (списком или колонками)-->
        <!-- Сделать фильтр по категориям (тарелки, кружки, наборы и тп) и по акциям -->
        <form class="d-flex mb-4" role="search" method="GET">
            <input class="form-control me-2" type="search" name="search" placeholder="Поиск товаров" aria-label="Поиск" value="<?php echo htmlspecialchars($searchQuery); ?>">
            <button class="btn btn-outline-success" type="submit">Искать</button>
        </form>

        <!-- вот тут сделать слайдер с акциями на товары -->
        <!-- Список товаров -->
        <div class="row">
            <?php if ($products): ?>
                <?php foreach ($products as $product): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card h-100">
                            <img src="<?php echo htmlspecialchars($product['image']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($product['name']); ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($product['name']); ?></h5>
                                <p class="card-text"><?php echo htmlspecialchars(mb_strimwidth($product['description'], 0, 50, '...'));?></p>
                                <p class="card-text"><strong><?php echo htmlspecialchars($product['price']); ?> руб.</strong></p>
                                <a href="product.php?id=<?php echo $product['id']; ?>" class="btn btn-primary">Подробнее</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="text-center">Товары не найдены.</p>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php include 'php/footer.php'; ?>
<!-- Подключение Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const toggle = document.querySelector(".navbar-toggler");
        const menu = document.querySelector("#navbarNavDropdown");
        if (toggle && menu) {
            toggle.addEventListener("click", function () {
                const bsCollapse = new bootstrap.Collapse(menu, {
                    toggle: false
                });
                if (menu.classList.contains("show")) {
                    bsCollapse.hide();
                } else {
                    bsCollapse.show();
                }
            });
        }
    });
</script>
</body>
</html>

