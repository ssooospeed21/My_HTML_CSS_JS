<?php
session_start();
require 'php/db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if ($username && $email && $password) {
        $stmt = $pdo->prepare('SELECT * FROM users WHERE username = :username OR email = :email');
        $stmt->execute(['username' => $username, 'email' => $email]);
        $existingUser = $stmt->fetch();

        if ($existingUser) {
            $error = 'Имя пользователя или email уже используются.';
        } else {
            $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare('INSERT INTO users (username, email, password) VALUES (:username, :email, :password)');
            $stmt->execute([
                'username' => $username,
                'email' => $email,
                'password' => $hashedPassword
            ]);
            header('Location: login.php');
            exit;
        }
    } else {
        $error = 'Заполните все поля.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include 'php/header.php'; ?>

<section class="auth-section">
    <div class="auth-container">
        <h1>Регистрация</h1>
        <?php if ($error): ?>
            <p class="error-message"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>
        <form method="POST">
            <input type="text" name="username" placeholder="Имя пользователя" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Пароль" required>
            <button type="submit">Зарегистрироваться</button>
        </form>
    </div>
</section>

<?php include 'php/footer.php'; ?>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const toggle = document.querySelector(".navbar-toggler");
        const menu = document.querySelector("#navbarNavDropdown");
        if (toggle && menu) {
            toggle.addEventListener("click", function () {
                const bsCollapse = new bootstrap.Collapse(menu, {
                    toggle: false
                });
                if (menu.classList.contains("show")) {
                    bsCollapse.hide();
                } else {
                    bsCollapse.show();
                }
            });
        }
    });
</script>
</body>
</html>
