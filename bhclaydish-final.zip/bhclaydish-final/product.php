<?php
session_start();
require 'php/db.php';

$productId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($productId <= 0) {
    die('Товар не найден.');
}

$isInFavorites = false;
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM favorites WHERE user_id = ? AND product_id = ?");
    $stmt->execute([$_SESSION['user_id'], $productId]);
    $isInFavorites = $stmt->fetchColumn() > 0;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_favorite'])) {
    if (!isset($_SESSION['user'])) {
        header('Location: login.php');
        exit;
    }

    $userId = (int)$_SESSION['user_id'];

    if ($isInFavorites) {
        // Удаляем из избранного
        $stmt = $pdo->prepare("DELETE FROM favorites WHERE user_id = ? AND product_id = ?");
        $stmt->execute([$userId, $productId]);
    } else {
        // Добавляем в избранное
        $stmt = $pdo->prepare("INSERT INTO favorites (user_id, product_id) VALUES (?, ?)");
        try {
            $stmt->execute([$userId, $productId]);
        } catch (PDOException $e) {
            // Игнорируем ошибку дубликата (если товар уже в избранном)
            if ($e->getCode() != 23000) { // Код ошибки дубликата в MySQL
                throw $e;
            }
        }
    }

    header("Location: product.php?id=$productId");
    exit;
}

// Получаем информацию о товаре
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$productId]);
$product = $stmt->fetch();

if (!$product) {
    die('Товар не найден.');
}


// Получаем акции для этого товара
$promotions = $pdo->prepare("
    SELECT p.* 
    FROM promotions p
    JOIN promotion_products pp ON p.id = pp.promotion_id
    WHERE pp.product_id = :product_id 
    AND p.start_date <= CURRENT_DATE() 
    AND p.end_date >= CURRENT_DATE()
    AND p.is_active = 1
    ORDER BY p.discount_percent DESC
");
$promotions->execute(['product_id' => $productId]);
$promotions = $promotions->fetchAll();

// Рассчитываем скидочную цену
$hasDiscount = !empty($promotions);
$discountPercent = $hasDiscount ? $promotions[0]['discount_percent'] : 0;
$finalPrice = $product['price'] * (1 - $discountPercent / 100);

// Получаем отзывы
$reviewsStmt = $pdo->prepare("
    SELECT r.comment, r.rating, r.created_at, u.username
    FROM reviews r
    JOIN users u ON r.user_id = u.id
    WHERE r.product_id = :product_id
    ORDER BY r.created_at DESC
");
$reviewsStmt->execute(['product_id' => $productId]);
$reviews = $reviewsStmt->fetchAll();

// Проверяем, покупал ли пользователь этот товар
$hasPurchased = false;
if (isset($_SESSION['user_id'])) {
    $userId = (int)$_SESSION['user_id'];

    $ordersStmt = $pdo->prepare("SELECT id FROM orders WHERE user_id = :user_id AND status = 'completed'");
    $ordersStmt->execute(['user_id' => $userId]);
    $orders = $ordersStmt->fetchAll(PDO::FETCH_COLUMN);

    if (!empty($orders)) {
        $placeholders = implode(',', array_fill(0, count($orders), '?'));
        $purchasedStmt = $pdo->prepare("
            SELECT COUNT(*) 
            FROM order_items 
            WHERE order_id IN ($placeholders) 
            AND product_id = ?
        ");

        $params = array_merge($orders, [$productId]);
        $purchasedStmt->execute($params);

        $hasPurchased = $purchasedStmt->fetchColumn() > 0;
    }
}

// Обработка добавления в корзину
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    if (!isset($_SESSION['user'])) {
        header('Location: login.php');
        exit;
    }

    $userId = (int)$_SESSION['user_id'];
    $productId = (int)$_GET['id'];
    $quantityToAdd = (int)$_POST['quantity'];

    // Проверяем доступное количество
    $stmt = $pdo->prepare("SELECT stock FROM products WHERE id = ?");
    $stmt->execute([$productId]);
    $stock = $stmt->fetchColumn();

    if ($stock < $quantityToAdd) {
        $_SESSION['error'] = 'Недостаточно товара на складе';
        header("Location: product.php?id=$productId");
        exit;
    }

    try {
        $pdo->beginTransaction();

        // Проверяем, есть ли уже такой товар в корзине
        $stmt = $pdo->prepare("SELECT id, quantity FROM cart WHERE user_id = ? AND product_id = ?");
        $stmt->execute([$userId, $productId]);
        $existingItem = $stmt->fetch();

        if ($existingItem) {
            // Обновляем количество существующего товара
            $newQuantity = $existingItem['quantity'] + $quantityToAdd;
            $stmt = $pdo->prepare("UPDATE cart SET quantity = ? WHERE id = ?");
            $stmt->execute([$newQuantity, $existingItem['id']]);
        } else {
            // Добавляем новый товар в корзину
            $stmt = $pdo->prepare("INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)");
            $stmt->execute([$userId, $productId, $quantityToAdd]);
        }

        // Уменьшаем количество на складе
        $stmt = $pdo->prepare("UPDATE products SET stock = stock - ? WHERE id = ?");
        $stmt->execute([$quantityToAdd, $productId]);

        $pdo->commit();
        header('Location: cart.php');
        exit;
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error'] = 'Ошибка при добавлении товара в корзину: ' . $e->getMessage();
        header("Location: product.php?id=$productId");
        exit;
    }
}

// Обработка добавления отзыва
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_review'])) {
    if (!isset($_SESSION['user'])) {
        die('Вы должны быть авторизованы для добавления отзыва.');
    }

    $userId = (int)$_SESSION['user_id'];
    $comment = trim($_POST['comment']);
    $rating = (int)$_POST['rating'];

    if (!$hasPurchased) {
        $review_error = 'Вы не можете оставить отзыв, так как не заказывали этот товар.';
    } elseif ($comment && $rating >= 1 && $rating <= 5) {
        $stmt = $pdo->prepare("INSERT INTO reviews (product_id, user_id, comment, rating) VALUES (:product_id, :user_id, :comment, :rating)");
        $stmt->execute([
            'product_id' => $productId,
            'user_id' => $userId,
            'comment' => $comment,
            'rating' => $rating,
        ]);

        header("Location: product.php?id=$productId");
        exit;
    } else {
        $review_error = 'Заполните корректно все поля.';
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['name']); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include 'php/header.php'; ?>

<section class="product-details py-5">
    <div class="container">
        <div class="row">
            <!-- Картинка товара -->
            <div class="col-md-6 mb-4 mb-md-0">
                <img src="<?php echo htmlspecialchars($product['image']); ?>" class="img-fluid rounded" alt="<?php echo htmlspecialchars($product['name']); ?>">
            </div>

            <!-- Информация о товаре -->
            <div class="col-md-6">
                <h1 class="mb-3"><?php echo htmlspecialchars($product['name']); ?></h1>
                <p class="text-muted mb-4"><?php echo htmlspecialchars($product['description']); ?></p>

                <!-- Блок с ценой и акцией -->
                <div class="price-block mb-4">
                    <?php if ($hasDiscount): ?>
                        <div class="promotion-badge mb-2">
                            <span class="badge bg-danger fs-5">
                                Участвует в акции: <?php echo htmlspecialchars($promotions[0]['title']); ?> (-<?php echo $discountPercent; ?>%)
                            </span>
                        </div>
                        <p class="fw-bold">
                            <span class="text-decoration-line-through text-muted me-2"><?php echo number_format($product['price'], 2, '.', ' '); ?> руб.</span>
                            <span class="text-warning fs-3"><?php echo number_format($finalPrice, 2, '.', ' '); ?> руб.</span>
                        </p>
                    <?php else: ?>
                        <p class="fw-bold fs-3">Цена: <?php echo number_format($product['price'], 2, '.', ' '); ?> руб.</p>
                    <?php endif; ?>
                </div>

                <p class="fw-light">Наличие: <?php echo htmlspecialchars($product['stock']); ?> шт.</p>

                <!-- Форма добавления в корзину -->
                <?php if (isset($_SESSION['user'])): ?>
                    <?php if ($product['stock'] > 0): ?>
                        <div class="d-flex align-items-center flex-wrap gap-3">
                            <form method="POST" class="d-flex align-items-center">
                                <input type="number" name="quantity" value="1" min="1" max="<?php echo htmlspecialchars($product['stock']); ?>" class="form-control w-25 me-2" required>
                                <button type="submit" name="add_to_cart" class="btn btn-primary">Добавить в корзину</button>
                            </form>
                            <form method="POST">
                                <button type="submit" name="toggle_favorite" class="btn <?= $isInFavorites ? 'btn-danger' : 'btn-warning' ?>">
                                    <?= $isInFavorites ? 'Удалить из избранного' : 'Добавить в избранное' ?>
                                </button>
                            </form>
                        </div>
                    <?php else: ?>
                        <div class="d-flex flex-column">
                            <p class="text-danger">Товар временно отсутствует.</p>
                            <form method="POST">
                                <button type="submit" name="add_to_favorites" class="btn btn-warning">Добавить в избранное</button>
                            </form>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <p>Чтобы добавить товар в корзину, войдите в систему.</p>
                <?php endif; ?>

                <?php if (isset($error)): ?>
                    <p class="text-danger mt-3"><?php echo htmlspecialchars($error); ?></p>
                <?php endif; ?>
            </div>
        </div>

        <hr class="my-5">

        <!-- Раздел отзывов -->
        <h2>Отзывы</h2>
        <?php if ($reviews): ?>
            <div class="list-group mb-5">
                <?php foreach ($reviews as $review): ?>
                    <div class="list-group-item">
                        <h5 class="mb-1"><?php echo htmlspecialchars($review['username']); ?></h5>
                        <p class="mb-1"><?php echo htmlspecialchars($review['comment']); ?></p>
                        <small>Рейтинг: <?php echo htmlspecialchars($review['rating']); ?> из 5 | <?php echo htmlspecialchars($review['created_at']); ?></small>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="text-muted">Пока нет отзывов. Будьте первым!</p>
        <?php endif; ?>

        <!-- Форма добавления отзыва -->
        <?php if (isset($_SESSION['user'])): ?>
            <h3>Добавить отзыв</h3>
            <?php if ($hasPurchased): ?>
                <form method="POST">
                    <div class="mb-3">
                        <textarea name="comment" rows="4" class="form-control" placeholder="Напишите ваш отзыв" required></textarea>
                    </div>
                    <div class="mb-3">
                        <select name="rating" class="form-select" required>
                            <option value="5">5 - Отлично</option>
                            <option value="4">4 - Хорошо</option>
                            <option value="3">3 - Средне</option>
                            <option value="2">2 - Плохо</option>
                            <option value="1">1 - Ужасно</option>
                        </select>
                    </div>
                    <button type="submit" name="submit_review" class="btn btn-success">Отправить</button>
                </form>
            <?php else: ?>
                <div class="alert alert-info">
                    Вы ещё не заказывали данный товар, чтобы оставлять отзыв о нём, заказывайте и делитесь впечатлениями о приобретённом товаре!
                </div>
            <?php endif; ?>
        <?php else: ?>
            <p>Войдите в систему, чтобы оставить отзыв.</p>
        <?php endif; ?>

        <?php if (isset($review_error)): ?>
            <p class="text-danger mt-3"><?php echo htmlspecialchars($review_error); ?></p>
        <?php endif; ?>
    </div>
</section>

<?php include 'php/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const toggle = document.querySelector(".navbar-toggler");
        const menu = document.querySelector("#navbarNavDropdown");
        if (toggle && menu) {
            toggle.addEventListener("click", function () {
                const bsCollapse = new bootstrap.Collapse(menu, {
                    toggle: false
                });
                if (menu.classList.contains("show")) {
                    bsCollapse.hide();
                } else {
                    bsCollapse.show();
                }
            });
        }
    });
</script>
</body>
</html>

