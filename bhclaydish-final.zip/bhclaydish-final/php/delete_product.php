<?php
session_start();
require 'db.php';

// Проверка прав администратора
if (!isset($_SESSION['user']) || $_SESSION['is_admin'] != 1) {
    header('Location: login.php');
    exit;
}

// Удаление товара
$id = $_GET['id'];
$stmt = $pdo->prepare("DELETE FROM products WHERE id = :id");
$stmt->execute(['id' => $id]);

header("Location: admin_panel.php");
exit;
?>