<footer class="footer">
    <div class="wrapper">
        <p class="text-small">Clay Dishes © 2024</p>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</footer>
