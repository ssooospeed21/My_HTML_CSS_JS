<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user'])) {
    header('Location: ../login.php');
    exit;
}

if (!isset($_POST['product_id'])) {
    header('Location: ../profile.php');
    exit;
}

$userId = (int)$_SESSION['user_id'];
$productId = (int)$_POST['product_id'];

// Удаляем конкретный товар из избранного
$stmt = $pdo->prepare("DELETE FROM favorites WHERE user_id = ? AND product_id = ?");
$stmt->execute([$userId, $productId]);

header('Location: ../profile.php');
exit;
?>
