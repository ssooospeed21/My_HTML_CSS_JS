<?php
session_start();
require 'db.php';

// Проверка авторизации
if (!isset($_SESSION['user'])) {
    header('Location: ../login.php');
    exit;
}

$orderId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Получаем детали заказа
$stmt = $pdo->prepare("
    SELECT o.id, o.user_id, o.total, o.status, o.created_at, u.username
    FROM orders o
    JOIN users u ON o.user_id = u.id
    WHERE o.id = :order_id
");
$stmt->execute(['order_id' => $orderId]);
$order = $stmt->fetch();

// Проверка прав доступа
if (!$order || ($order['user_id'] != $_SESSION['user_id'] && $_SESSION['is_admin'] != 1)) {
    die('Нет доступа или заказ не найден.');
}

// Получаем товары в заказе
$stmt = $pdo->prepare("
    SELECT oi.product_id, p.name, oi.quantity, oi.price
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    WHERE oi.order_id = :order_id
");
$stmt->execute(['order_id' => $orderId]);
$orderItems = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Детали заказа</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include 'header.php'; ?>

<section class="order-details py-5">
    <div class="container">
        <h1 class="text-center mb-4">Детали заказа №<?php echo $order['id']; ?></h1>

        <div class="mb-4">
            <p><strong>Пользователь:</strong> <?php echo htmlspecialchars($order['username']); ?></p>
            <p><strong>Дата создания:</strong> <?php echo $order['created_at']; ?></p>
            <p><strong>Общая сумма:</strong> <?php echo $order['total']; ?> руб.</p>
            <p><strong>Статус:</strong>
                <span class="badge bg-<?php echo ($order['status'] == 'pending' ? 'warning' : ($order['status'] == 'completed' ? 'success' : 'danger')); ?>">
                    <?php echo ucfirst($order['status']); ?>
                </span>
            </p>
        </div>

        <h3 class="mb-3">Товары в заказе</h3>
        <table class="table table-striped">
            <thead>
            <tr>
                <th scope="col">Товар</th>
                <th scope="col">Цена</th>
                <th scope="col">Количество</th>
                <th scope="col">Сумма</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($orderItems as $item): ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                    <td><?php echo $item['price']; ?> руб.</td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td><?php echo $item['price'] * $item['quantity']; ?> руб.</td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

        <?php if ($_SESSION['is_admin'] == 1): ?>
            <!-- Формуля для изменения статуса заказа (только для администратора) -->
            <form method="POST" class="mt-4">
                <div class="mb-3">
                    <label for="status" class="form-label">Изменить статус</label>
                    <select name="status" id="status" class="form-select">
                        <option value="pending" <?php echo ($order['status'] == 'pending') ? 'selected' : ''; ?>>Ожидает</option>
                        <option value="completed" <?php echo ($order['status'] == 'completed') ? 'selected' : ''; ?>>Завершен</option>
                        <option value="canceled" <?php echo ($order['status'] == 'canceled') ? 'selected' : ''; ?>>Отменен</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Обновить статус</button>
            </form>
        <?php endif; ?>
    </div>
</section>

<?php include 'footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const toggle = document.querySelector(".navbar-toggler");
        const menu = document.querySelector("#navbarNavDropdown");
        if (toggle && menu) {
            toggle.addEventListener("click", function () {
                const bsCollapse = new bootstrap.Collapse(menu, {
                    toggle: false
                });
                if (menu.classList.contains("show")) {
                    bsCollapse.hide();
                } else {
                    bsCollapse.show();
                }
            });
        }
    });
</script>
</body>
</html>
