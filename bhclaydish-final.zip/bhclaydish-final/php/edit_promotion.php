<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user']) || $_SESSION['is_admin'] != 1) {
    header('Location: login.php');
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: admin_panel.php');
    exit;
}

$promotionId = (int)$_GET['id'];
$promotion = $pdo->prepare("SELECT * FROM promotions WHERE id = ?");
$promotion->execute([$promotionId]);
$promotion = $promotion->fetch();

if (!$promotion) {
    header('Location: admin_panel.php');
    exit;
}

$products = $pdo->query("SELECT id, name FROM products")->fetchAll();
$selectedProducts = $pdo->prepare("SELECT product_id FROM promotion_products WHERE promotion_id = ?");
$selectedProducts->execute([$promotionId]);
$selectedProducts = $selectedProducts->fetchAll(PDO::FETCH_COLUMN);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $discountPercent = (int)$_POST['discount_percent'];
    $startDate = $_POST['start_date'];
    $endDate = $_POST['end_date'];
    $newSelectedProducts = $_POST['products'] ?? [];

    // Загрузка изображения
    $imagePath = $promotion['image'];
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../img/promotions/';
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        // Удаляем старое изображение, если оно есть
        if ($imagePath && file_exists('../' . $imagePath)) {
            unlink('../' . $imagePath);
        }

        $extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $filename = uniqid() . '.' . $extension;
        $destination = $uploadDir . $filename;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $destination)) {
            $imagePath = 'img/promotions/' . $filename;
        }
    }

    try {
        $pdo->beginTransaction();

        // Обновляем акцию
        $stmt = $pdo->prepare("
            UPDATE promotions 
            SET title = :title, description = :description, discount_percent = :discount_percent, 
                start_date = :start_date, end_date = :end_date, image = :image
            WHERE id = :id
        ");
        $stmt->execute([
            ':title' => $title,
            ':description' => $description,
            ':discount_percent' => $discountPercent,
            ':start_date' => $startDate,
            ':end_date' => $endDate,
            ':image' => $imagePath,
            ':id' => $promotionId
        ]);

        // Удаляем старые связи с товарами
        $stmt = $pdo->prepare("DELETE FROM promotion_products WHERE promotion_id = ?");
        $stmt->execute([$promotionId]);

        // Добавляем новые связи с товарами
        if (!empty($newSelectedProducts)) {
            $stmt = $pdo->prepare("INSERT INTO promotion_products (promotion_id, product_id) VALUES (:promotion_id, :product_id)");
            foreach ($newSelectedProducts as $productId) {
                $stmt->execute([
                    ':promotion_id' => $promotionId,
                    ':product_id' => $productId
                ]);
            }
        }

        $pdo->commit();
        header('Location: admin_panel.php');
        exit;
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Ошибка при обновлении акции: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Редактировать акцию</title>
    <link rel="stylesheet" href="../css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include 'header.php'; ?>

<div class="container py-5">
    <h1 class="mb-4">Редактировать акцию</h1>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="title" class="form-label">Название акции</label>
            <input type="text" class="form-control" id="title" name="title" value="<?php echo htmlspecialchars($promotion['title']); ?>" required>
        </div>

        <div class="mb-3">
            <label for="description" class="form-label">Описание акции</label>
            <textarea class="form-control" id="description" name="description" rows="3" required><?php echo htmlspecialchars($promotion['description']); ?></textarea>
        </div>

        <div class="mb-3">
            <label for="discount_percent" class="form-label">Скидка в процентах</label>
            <input type="number" class="form-control" id="discount_percent" name="discount_percent" min="1" max="100" value="<?php echo $promotion['discount_percent']; ?>" required>
        </div>

        <div class="row mb-3">
            <div class="col-md-6">
                <label for="start_date" class="form-label">Дата начала</label>
                <input type="date" class="form-control" id="start_date" name="start_date" value="<?php echo $promotion['start_date']; ?>" required>
            </div>
            <div class="col-md-6">
                <label for="end_date" class="form-label">Дата окончания</label>
                <input type="date" class="form-control" id="end_date" name="end_date" value="<?php echo $promotion['end_date']; ?>" required>
            </div>
        </div>

        <div class="mb-3">
            <label for="image" class="form-label">Изображение для акции</label>
            <?php if ($promotion['image']): ?>
                <div class="mb-2">
                    <img src="../<?php echo htmlspecialchars($promotion['image']); ?>" alt="Текущее изображение" style="max-height: 200px;">
                    <div class="form-check mt-2">
                        <input class="form-check-input" type="checkbox" id="delete_image" name="delete_image">
                        <label class="form-check-label" for="delete_image">Удалить текущее изображение</label>
                    </div>
                </div>
            <?php endif; ?>
            <input type="file" class="form-control" id="image" name="image">
        </div>

        <div class="mb-3">
            <label class="form-label">Товары, участвующие в акции</label>
            <select class="form-select" name="products[]" multiple size="5">
                <?php foreach ($products as $product): ?>
                    <option value="<?php echo $product['id']; ?>" <?php echo in_array($product['id'], $selectedProducts) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($product['name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <small class="text-muted">Для выбора нескольких товаров удерживайте Ctrl (Windows) или Command (Mac)</small>
        </div>

        <button type="submit" class="btn btn-primary">Сохранить изменения</button>
        <a href="admin_panel.php" class="btn btn-secondary">Отмена</a>
    </form>
</div>

<?php include 'footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const toggle = document.querySelector(".navbar-toggler");
        const menu = document.querySelector("#navbarNavDropdown");
        if (toggle && menu) {
            toggle.addEventListener("click", function () {
                const bsCollapse = new bootstrap.Collapse(menu, {
                    toggle: false
                });
                if (menu.classList.contains("show")) {
                    bsCollapse.hide();
                } else {
                    bsCollapse.show();
                }
            });
        }
    });
</script>
</body>
</html>
