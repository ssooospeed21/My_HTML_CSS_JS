<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user']) || $_SESSION['is_admin'] != 1) {
    header('Location: login.php');
    exit;
}

$products = $pdo->query("SELECT * FROM products")->fetchAll();



$reviewsStmt = $pdo->query("
    SELECT r.id, r.comment, r.rating, r.created_at, u.username, p.name AS product_name
    FROM reviews r
    JOIN users u ON r.user_id = u.id
    JOIN products p ON r.product_id = p.id
    ORDER BY r.created_at DESC
");
$reviews = $reviewsStmt->fetchAll();

if (isset($_GET['delete_review_id'])) {
    $reviewId = (int)$_GET['delete_review_id'];
    $stmt = $pdo->prepare("DELETE FROM reviews WHERE id = :id");
    $stmt->execute(['id' => $reviewId]);

    header('Location: admin_panel.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Администрирование</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include 'header.php'; ?>

<section class="admin-panel py-5">
    <div class="container">
        <h1 class="mb-4">Панель администратора</h1>
        <div class="mb-5">
            <h2 class="mb-3">Управление Заказами</h2>
            <a href="orders_admin.php" class="btn btn-primary mb-3">Заказы</a>
        </div>

        <!-- Управление акциями -->
        <div class="mb-5">
            <h2 class="mb-3">Управление акциями</h2>
            <a href="add_promotion.php" class="btn btn-primary mb-3">Добавить акцию</a>

            <?php
            $promotions = $pdo->query("
        SELECT p.*, COUNT(pp.product_id) as product_count 
        FROM promotions p
        LEFT JOIN promotion_products pp ON p.id = pp.promotion_id
        GROUP BY p.id
        ORDER BY p.start_date DESC
    ")->fetchAll();
            ?>

            <?php if ($promotions): ?>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Название</th>
                            <th>Скидка</th>
                            <th>Период</th>
                            <th>Товаров</th>
                            <th>Действия</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($promotions as $promotion): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($promotion['id']); ?></td>
                                <td><?php echo htmlspecialchars($promotion['title']); ?></td>
                                <td><?php echo htmlspecialchars($promotion['discount_percent']); ?>%</td>
                                <td>
                                    <?php
                                    echo date('d.m.Y', strtotime($promotion['start_date'])) . ' - ' .
                                        date('d.m.Y', strtotime($promotion['end_date']));
                                    ?>
                                </td>
                                <td><?php echo htmlspecialchars($promotion['product_count']); ?></td>
                                <td>
                                    <a href="edit_promotion.php?id=<?php echo $promotion['id']; ?>" class="btn btn-warning btn-sm">Изменить</a>
                                    <a href="delete_promotion.php?id=<?php echo $promotion['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Вы уверены, что хотите удалить эту акцию?')">Удалить</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted">Акций пока нет.</p>
            <?php endif; ?>
        </div>

        <!-- Управление товарами -->
        <div class="mb-5">
            <h2 class="mb-3">Управление товарами</h2>
            <a href="add_product.php" class="btn btn-primary mb-3">Добавить товар</a>
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Название</th>
                        <th>Цена</th>
                        <th>Количество</th>
                        <th>Действия</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($products as $product): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($product['id']); ?></td>
                            <td><?php echo htmlspecialchars($product['name']); ?></td>
                            <td><?php echo htmlspecialchars($product['price']); ?> руб.</td>
                            <td><?php echo htmlspecialchars($product['stock']); ?></td>
                            <td>
                                <a href="edit_product.php?id=<?php echo $product['id']; ?>" class="btn btn-warning btn-sm">Изменить</a>
                                <a href="delete_product.php?id=<?php echo $product['id']; ?>" class="btn btn-danger btn-sm">Удалить</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Управление отзывами -->
        <div>
            <h2 class="mb-3">Отзывы</h2>
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Товар</th>
                        <th>Пользователь</th>
                        <th>Рейтинг</th>
                        <th>Комментарий</th>
                        <th>Дата</th>
                        <th>Действия</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($reviews as $review): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($review['id']); ?></td>
                            <td><?php echo htmlspecialchars($review['product_name']); ?></td>
                            <td><?php echo htmlspecialchars($review['username']); ?></td>
                            <td><?php echo htmlspecialchars($review['rating']); ?> из 5</td>
                            <td><?php echo htmlspecialchars($review['comment']); ?></td>
                            <td><?php echo htmlspecialchars($review['created_at']); ?></td>
                            <td>
                                <a href="admin_panel.php?delete_review_id=<?php echo $review['id']; ?>" class="btn btn-danger btn-sm">Удалить</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const toggle = document.querySelector(".navbar-toggler");
        const menu = document.querySelector("#navbarNavDropdown");
        if (toggle && menu) {
            toggle.addEventListener("click", function () {
                const bsCollapse = new bootstrap.Collapse(menu, {
                    toggle: false
                });
                if (menu.classList.contains("show")) {
                    bsCollapse.hide();
                } else {
                    bsCollapse.show();
                }
            });
        }
    });
</script>
</body>
</html>
