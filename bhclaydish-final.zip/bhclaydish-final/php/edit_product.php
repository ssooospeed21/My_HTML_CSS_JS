<?php
session_start();
require 'db.php';

// Проверка прав администратора
if (!isset($_SESSION['user']) || $_SESSION['is_admin'] != 1) {
    header('Location: login.php');
    exit;
}

// Получение данных товара
$id = $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = :id");
$stmt->execute(['id' => $id]);
$product = $stmt->fetch();

if (!$product) {
    die('Товар не найден.');
}

// Обновление данных товара
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $image = $_FILES['image'];

    $updateQuery = "UPDATE products SET name = :name, description = :description, price = :price, stock = :stock";
    $params = [
        'name' => $name,
        'description' => $description,
        'price' => $price,
        'stock' => $stock,
    ];

    if ($image['size'] > 0) {
        $targetDir = 'img/';
        $fileName = basename($image['name']);
        $targetFilePath = $targetDir . $fileName;

        if (move_uploaded_file($image['tmp_name'], $targetFilePath)) {
            $updateQuery .= ", image = :image";
            $params['image'] = $fileName;
        }
    }

    $updateQuery .= " WHERE id = :id";
    $params['id'] = $id;

    $stmt = $pdo->prepare($updateQuery);
    $stmt->execute($params);

    header("Location: admin_panel.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Редактировать товар</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include 'header.php'; ?>

<section class="auth-section py-5">
    <div class="container">
        <div class="auth-container mx-auto p-4 border rounded shadow-lg" style="max-width: 600px;">
            <h1 class="text-center mb-4">Редактировать товар</h1>
            <form method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="name" class="form-label">Название товара</label>
                    <input type="text" name="name" id="name" class="form-control" value="<?php echo htmlspecialchars($product['name']); ?>" required>
                </div>

                <div class="mb-3">
                    <label for="description" class="form-label">Описание</label>
                    <textarea name="description" id="description" class="form-control" rows="4" required><?php echo htmlspecialchars($product['description']); ?></textarea>
                </div>

                <div class="mb-3">
                    <label for="price" class="form-label">Цена</label>
                    <input type="number" name="price" id="price" class="form-control" value="<?php echo htmlspecialchars($product['price']); ?>" step="0.01" required>
                </div>

                <div class="mb-3">
                    <label for="stock" class="form-label">Количество на складе</label>
                    <input type="number" name="stock" id="stock" class="form-control" value="<?php echo htmlspecialchars($product['stock']); ?>" required>
                </div>

                <div class="mb-3">
                    <label for="image" class="form-label">Изображение</label>
                    <input type="file" name="image" id="image" class="form-control">
                </div>

                <button type="submit" class="btn btn-primary w-100">Сохранить изменения</button>
            </form>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const toggle = document.querySelector(".navbar-toggler");
        const menu = document.querySelector("#navbarNavDropdown");
        if (toggle && menu) {
            toggle.addEventListener("click", function () {
                const bsCollapse = new bootstrap.Collapse(menu, {
                    toggle: false
                });
                if (menu.classList.contains("show")) {
                    bsCollapse.hide();
                } else {
                    bsCollapse.show();
                }
            });
        }
    });
</script>
</body>
</html>


