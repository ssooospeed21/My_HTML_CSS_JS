<header>
    <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm">
        <div class="container">
            <!-- Логотип -->
            <a class="navbar-brand d-flex align-items-center" href="../index.php">
                <img src="../img/claydisheslogo.svg" alt="Логотип" width="40" class="me-2">
                <span class="fs-4 fw-bold">Clay Dishes</span>
            </a>

            <!-- Кнопка-бургер -->
            <button class="navbar-toggler" type="button" id="navbarToggle">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Навигация -->
            <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
                <ul class="navbar-nav text-end">
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">Главная</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../magazin.php">Каталог</a>
                    </li>
                    <?php if (isset($_SESSION['user'])): ?>
                        <?php if ($_SESSION['is_admin'] == 1): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="../php/admin_panel.php">Администрирование</a>
                            </li>
                        <?php endif; ?>
                        <li class="nav-item">
                            <a class="nav-link" href="../profile.php">Профиль</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../logout.php">Выход</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="../login.php">Вход</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../reg.php">Регистрация</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
</header>
