<?php
session_start();
require 'db.php';

// Проверка авторизации
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = (int)$_SESSION['user_id'];

// Получение заказов пользователя
$stmt = $pdo->prepare("
    SELECT o.id, o.total, o.status, o.created_at
    FROM orders o
    WHERE o.user_id = :user_id
");
$stmt->execute(['user_id' => $userId]);
$orders = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мои заказы</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include 'header.php'; ?>

<section class="orders py-5">
    <div class="container">
        <h1 class="text-center mb-4">Мои заказы</h1>

        <?php if (count($orders) > 0): ?>
            <div class="list-group">
                <?php foreach ($orders as $order): ?>
                    <div class="list-group-item">
                        <h5 class="mb-3">Заказ №<?php echo $order['id']; ?></h5>
                        <p>Дата: <?php echo $order['created_at']; ?></p>
                        <p>Общая сумма: <?php echo $order['total']; ?> руб.</p>
                        <p>Статус: <span class="badge bg-<?php echo $order['status'] === 'pending' ? 'warning' : ($order['status'] === 'completed' ? 'success' : 'danger'); ?>">
                            <?php echo ucfirst($order['status']); ?>
                        </span></p>
                        <a href="order_details.php?id=<?php echo $order['id']; ?>" class="btn btn-info">Подробнее</a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="text-center">У вас нет заказов.</p>
        <?php endif; ?>
    </div>
</section>

<?php include 'footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const toggle = document.querySelector(".navbar-toggler");
        const menu = document.querySelector("#navbarNavDropdown");
        if (toggle && menu) {
            toggle.addEventListener("click", function () {
                const bsCollapse = new bootstrap.Collapse(menu, {
                    toggle: false
                });
                if (menu.classList.contains("show")) {
                    bsCollapse.hide();
                } else {
                    bsCollapse.show();
                }
            });
        }
    });
</script>
</body>
</html>
