<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user']) || $_SESSION['is_admin'] != 1) {
    header('Location: login.php');
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: admin_panel.php');
    exit;
}

$promotionId = (int)$_GET['id'];

// Получаем информацию об акции для удаления изображения
$promotion = $pdo->prepare("SELECT image FROM promotions WHERE id = ?");
$promotion->execute([$promotionId]);
$promotion = $promotion->fetch();

try {
    $pdo->beginTransaction();

    // Удаляем связи с товарами
    $stmt = $pdo->prepare("DELETE FROM promotion_products WHERE promotion_id = ?");
    $stmt->execute([$promotionId]);

    // Удаляем саму акцию
    $stmt = $pdo->prepare("DELETE FROM promotions WHERE id = ?");
    $stmt->execute([$promotionId]);

    // Удаляем изображение, если оно есть
    if ($promotion && $promotion['image'] && file_exists('../' . $promotion['image'])) {
        unlink('../' . $promotion['image']);
    }

    $pdo->commit();
} catch (Exception $e) {
    $pdo->rollBack();
}

header('Location: admin_panel.php');
exit;
?>
