<?php
session_start();
require 'php/db.php';

$error = '';
$success = '';

// Обработка основной формы авторизации
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if ($username && $password) {
        $stmt = $pdo->prepare('SELECT * FROM users WHERE username = :username');
        $stmt->execute(['username' => $username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user'] = $user['username'];
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['is_admin'] = $user['is_admin'];
            header('Location: ../index.php');
            exit;
        } else {
            $error = 'Неправильное имя пользователя или пароль.';
        }
    } else {
        $error = 'Заполните все поля.';
    }
}

// Обработка восстановления пароля (шаг 1 - email)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset_email'])) {
    $email = trim($_POST['reset_email']);

    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $stmt = $pdo->prepare('SELECT * FROM users WHERE email = :email');
        $stmt->execute(['email' => $email]);
        $user = $stmt->fetch();

        if ($user) {
            $code = rand(100000, 999999);
            $_SESSION['reset_code'] = $code;
            $_SESSION['reset_email'] = $email;
            $_SESSION['code_expire'] = time() + 1800;
            $_SESSION['show_password_step'] = true; // Флаг для показа шага с паролем

            // В реальном приложении:
            mail($email, 'Код подтверждения', "Ваш код подтверждения: $code");

            $success = "Код подтверждения отправлен на $email";

            // Возвращаем JSON для AJAX обработки
            if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
                echo json_encode(['success' => true, 'message' => $success]);
                exit;
            }
        } else {
            $error = 'Пользователь с таким email не найден.';
            if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
                echo json_encode(['success' => false, 'error' => $error]);
                exit;
            }
        }
    } else {
        $error = 'Введите корректный email.';
        if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            echo json_encode(['success' => false, 'error' => $error]);
            exit;
        }
    }
}

// Обработка восстановления пароля (шаг 2 - код и новый пароль)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset_code'])) {
    $code = trim($_POST['reset_code']);
    $new_password = trim($_POST['new_password']);
    $confirm_password = trim($_POST['confirm_password']);
    $email = $_SESSION['reset_email'] ?? '';

    if (time() > ($_SESSION['code_expire'] ?? 0)) {
        $error = 'Срок действия кода истёк. Запросите новый код.';
        unset($_SESSION['reset_code'], $_SESSION['reset_email'], $_SESSION['code_expire'], $_SESSION['show_password_step']);
    } elseif ($code != ($_SESSION['reset_code'] ?? '')) {
        $error = 'Неверный код подтверждения.';
    } elseif ($new_password !== $confirm_password) {
        $error = 'Пароли не совпадают.';
    } elseif (strlen($new_password) < 6) {
        $error = 'Пароль должен содержать минимум 6 символов.';
    } else {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare('UPDATE users SET password = :password WHERE email = :email');
        $stmt->execute(['password' => $hashed_password, 'email' => $email]);

        $success = 'Пароль успешно изменён. Теперь вы можете войти с новым паролем.';
        unset($_SESSION['reset_code'], $_SESSION['reset_email'], $_SESSION['code_expire'], $_SESSION['show_password_step']);

        if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            echo json_encode(['success' => true, 'message' => $success, 'completed' => true]);
            exit;
        }
    }

    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        echo json_encode(['success' => false, 'error' => $error]);
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <style>
        .step {
            display: none;
        }
        .step.active {
            display: block;
        }
    </style>
</head>
<body>
<?php include 'php/header.php'; ?>

<section class="auth-section">
    <div class="auth-container">
        <h1 class="text-center mb-4">Вход</h1>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        <form method="POST" class="mb-3">
            <div class="mb-3">
                <input type="text" name="username" class="form-control" placeholder="Имя пользователя" required>
            </div>
            <div class="mb-3">
                <input type="password" name="password" class="form-control" placeholder="Пароль" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Войти</button>
        </form>
        <p class="text-center mt-3">
            <a href="#" class="text-decoration-none" data-bs-toggle="modal" data-bs-target="#resetModal">Забыли пароль?</a>
        </p>
    </div>
</section>

<!-- Модальное окно восстановления пароля -->
<div class="modal fade" id="resetModal" tabindex="-1" aria-labelledby="resetModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="resetModalLabel">Восстановление пароля</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Шаг 1: Ввод email -->
                <div id="step1" class="step active">
                    <p>Введите email, указанный при регистрации:</p>
                    <form id="resetForm1" method="POST">
                        <div class="mb-3">
                            <input type="email" name="reset_email" class="form-control" placeholder="Ваш email" required>
                        </div>
                        <div id="emailError" class="alert alert-danger d-none"></div>
                        <button type="submit" class="btn btn-primary w-100">Отправить код</button>
                    </form>
                </div>

                <!-- Шаг 2: Ввод кода и нового пароля -->
                <div id="step2" class="step">
                    <p>На ваш email отправлен код подтверждения. Введите его и новый пароль:</p>
                    <form id="resetForm2" method="POST">
                        <div class="mb-3">
                            <input type="text" name="reset_code" class="form-control" placeholder="Код подтверждения" required>
                        </div>
                        <div class="mb-3">
                            <input type="password" name="new_password" class="form-control" placeholder="Новый пароль" required>
                        </div>
                        <div class="mb-3">
                            <input type="password" name="confirm_password" class="form-control" placeholder="Повторите пароль" required>
                        </div>
                        <div id="passwordError" class="alert alert-danger d-none"></div>
                        <button type="submit" class="btn btn-primary w-100">Изменить пароль</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Функция для полного закрытия модального окна
    function closeModal() {
        const modal = bootstrap.Modal.getInstance(document.getElementById('resetModal'));
        modal.hide();

        // Удаляем бэкдроп вручную
        document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());
        document.body.classList.remove('modal-open');
        document.body.style.paddingRight = '';
    }

    // Обработка отправки первой формы (email)
    document.getElementById("resetForm1").addEventListener("submit", function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        const errorElement = document.getElementById('emailError');
        errorElement.classList.add('d-none');

        fetch('', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Переключаем на шаг с паролем
                    document.getElementById('step1').classList.remove('active');
                    document.getElementById('step2').classList.add('active');

                    // Показываем сообщение об успехе
                    const successElement = document.createElement('div');
                    successElement.className = 'alert alert-success mt-3';
                    successElement.textContent = data.message;
                    document.getElementById('step2').prepend(successElement);
                } else {
                    // Показываем ошибку
                    errorElement.textContent = data.error;
                    errorElement.classList.remove('d-none');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                errorElement.textContent = 'Произошла ошибка. Попробуйте еще раз.';
                errorElement.classList.remove('d-none');
            });
    });

    // Обработка отправки второй формы (код и пароль)
    document.getElementById("resetForm2").addEventListener("submit", function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        const errorElement = document.getElementById('passwordError');
        errorElement.classList.add('d-none');

        fetch('', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Создаем сообщение об успехе
                    const alertDiv = document.createElement('div');
                    alertDiv.className = 'alert alert-success';
                    alertDiv.textContent = data.message;

                    // Добавляем сообщение на основную страницу
                    document.querySelector('.auth-container').prepend(alertDiv);

                    // Полностью закрываем модальное окно
                    closeModal();

                    // Через 5 секунд убираем сообщение
                    setTimeout(() => alertDiv.remove(), 5000);

                    // Сбрасываем формы в модальном окне
                    document.getElementById('resetForm1').reset();
                    document.getElementById('resetForm2').reset();
                    document.getElementById('step1').classList.add('active');
                    document.getElementById('step2').classList.remove('active');

                } else {
                    // Показываем ошибку
                    errorElement.textContent = data.error;
                    errorElement.classList.remove('d-none');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                errorElement.textContent = 'Произошла ошибка. Попробуйте еще раз.';
                errorElement.classList.remove('d-none');
            });
    });

    // Сброс формы при открытии модального окна
    document.getElementById('resetModal').addEventListener('show.bs.modal', function () {
        document.getElementById('step1').classList.add('active');
        document.getElementById('step2').classList.remove('active');
        document.getElementById('resetForm1').reset();
        document.getElementById('resetForm2').reset();
        document.getElementById('emailError').classList.add('d-none');
        document.getElementById('passwordError').classList.add('d-none');
    });

    // Дополнительная очистка при закрытии модального окна
    document.getElementById('resetModal').addEventListener('hidden.bs.modal', function () {
        // Удаляем все бэкдропы на всякий случай
        document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());
        document.body.classList.remove('modal-open');
        document.body.style.paddingRight = '';
    });
</script>

<?php include 'php/footer.php'; ?>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const toggle = document.querySelector(".navbar-toggler");
        const menu = document.querySelector("#navbarNavDropdown");
        if (toggle && menu) {
            toggle.addEventListener("click", function () {
                const bsCollapse = new bootstrap.Collapse(menu, {
                    toggle: false
                });
                if (menu.classList.contains("show")) {
                    bsCollapse.hide();
                } else {
                    bsCollapse.show();
                }
            });
        }
    });
</script>
</body>
</html>
