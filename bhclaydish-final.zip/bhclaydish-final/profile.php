<?php
session_start();
require 'php/db.php';
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

$userId = (int)$_SESSION['user_id'];
$stmt = $pdo->prepare("
    SELECT DISTINCT p.id, p.name, p.price, p.image,
    COALESCE(
        (SELECT MAX(pr.discount_percent) 
         FROM promotions pr 
         JOIN promotion_products pp ON pr.id = pp.promotion_id
         WHERE pp.product_id = p.id 
         AND pr.start_date <= CURRENT_DATE() 
         AND pr.end_date >= CURRENT_DATE()
         AND pr.is_active = 1),
        0
    ) AS discount_percent
    FROM favorites f
    JOIN products p ON f.product_id = p.id
    WHERE f.user_id = :user_id
");
$stmt->execute(['user_id' => $userId]);
$favorites = $stmt->fetchAll();

// Рассчитываем скидочные цены
foreach ($favorites as &$favorite) {
    $favorite['discounted_price'] = $favorite['price'] * (1 - $favorite['discount_percent'] / 100);
}
unset($favorite); // Важно: разрываем ссылку
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Профиль</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <style>
        .discounted-price {
            color: #dc3545;
            font-weight: bold;
        }
        .original-price {
            text-decoration: line-through;
            color: #6c757d;
        }
        .discount-badge {
            position: absolute;
            top: 10px;
            right: 10px;
        }
    </style>
</head>
<body>
<?php include 'php/header.php'; ?>

<section class="profile-section py-5">
    <div class="container text-center">
        <h1 class="display-4 mb-4">Добро пожаловать, <?php echo htmlspecialchars($_SESSION['user']); ?>!</h1>
        <p class="lead mb-4">Ваши личные данные и настройки</p>

        <div class="d-flex justify-content-center gap-3 flex-wrap">
            <a href="cart.php" class="btn btn-primary btn-lg">Перейти в корзину</a>
            <a href="php/orders.php" class="btn btn-primary btn-lg">Перейти к заказам</a>
            <a href="logout.php" class="btn btn-danger btn-lg">Выйти</a>
        </div>
    </div>
</section>

<section class="profile-section py-5">
    <div class="container">
        <h2 class="mb-4">Избранные товары</h2>

        <?php if (count($favorites) > 0): ?>
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-4">
                <?php foreach ($favorites as $favorite): ?>
                    <div class="col">
                        <div class="card h-100 position-relative">
                            <?php if ($favorite['discount_percent'] > 0): ?>
                                <span class="badge bg-danger discount-badge">-<?= $favorite['discount_percent'] ?>%</span>
                            <?php endif; ?>

                            <img src="<?= htmlspecialchars($favorite['image']) ?>"
                                 class="card-img-top"
                                 alt="<?= htmlspecialchars($favorite['name']) ?>"
                                 style="height: 200px; object-fit: cover;">

                            <div class="card-body d-flex flex-column">
                                <h5 class="card-title">
                                    <a href="product.php?id=<?= $favorite['id'] ?>" class="text-decoration-none">
                                        <?= htmlspecialchars($favorite['name']) ?>
                                    </a>
                                </h5>

                                <div class="mt-auto">
                                    <?php if ($favorite['discount_percent'] > 0): ?>
                                        <p class="card-text mb-1">
                                            <span class="original-price"><?= number_format($favorite['price'], 2, '.', ' ') ?> руб.</span>
                                        </p>
                                        <p class="card-text discounted-price">
                                            <?= number_format($favorite['discounted_price'], 2, '.', ' ') ?> руб.
                                        </p>
                                    <?php else: ?>
                                        <p class="card-text">
                                            <?= number_format($favorite['price'], 2, '.', ' ') ?> руб.
                                        </p>
                                    <?php endif; ?>

                                    <form method="POST" action="php/remove_favorite.php" class="mt-2">
                                        <input type="hidden" name="product_id" value="<?= $favorite['id'] ?>">
                                        <button type="submit" class="btn btn-danger w-100">Удалить из избранного</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-4">
                <p class="text-muted fs-5">У вас нет избранных товаров.</p>
                <a href="magazin.php" class="btn btn-primary">Перейти в каталог</a>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php include 'php/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const toggle = document.querySelector(".navbar-toggler");
        const menu = document.querySelector("#navbarNavDropdown");
        if (toggle && menu) {
            toggle.addEventListener("click", function () {
                const bsCollapse = new bootstrap.Collapse(menu, {
                    toggle: false
                });
                if (menu.classList.contains("show")) {
                    bsCollapse.hide();
                } else {
                    bsCollapse.show();
                }
            });
        }
    });
</script>

</body>
</html>
