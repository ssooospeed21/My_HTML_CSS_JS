<?php
ob_start();
session_start();
require 'php/db.php';

if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

$userId = (int)$_SESSION['user_id'];

// Получаем товары в корзине с информацией о скидках
$stmt = $pdo->prepare("
    SELECT 
        c.id as cart_id,
        p.id as product_id, 
        p.name, 
        p.price, 
        c.quantity, 
        p.image,
        COALESCE(
            (SELECT MAX(pr.discount_percent) 
             FROM promotions pr 
             JOIN promotion_products pp ON pr.id = pp.promotion_id
             WHERE pp.product_id = p.id 
             AND pr.start_date <= CURRENT_DATE() 
             AND pr.end_date >= CURRENT_DATE()
             AND pr.is_active = 1),
            0
        ) AS discount_percent
    FROM cart c
    JOIN products p ON c.product_id = p.id
    WHERE c.user_id = :user_id
");
$stmt->execute(['user_id' => $userId]);
$cartItems = $stmt->fetchAll();

// Рассчитываем итоговые суммы
$total = 0;
$totalDiscount = 0;
foreach ($cartItems as $key => $item) {
    $cartItems[$key]['discounted_price'] = $item['price'] * (1 - $item['discount_percent'] / 100);
    $cartItems[$key]['total_price'] = $cartItems[$key]['discounted_price'] * $item['quantity'];
    $cartItems[$key]['total_original_price'] = $item['price'] * $item['quantity'];

    $total += $cartItems[$key]['total_price'];
    $totalDiscount += $cartItems[$key]['total_original_price'] - $cartItems[$key]['total_price'];
}
unset($item);

// Удаление товара из корзины
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_item'])) {
    $cartId = (int)$_POST['cart_id'];
    $quantityToRemove = (int)$_POST['delete_quantity'];

    if ($cartId > 0 && $quantityToRemove > 0) {
        try {
            $pdo->beginTransaction();

            // Получаем информацию о товаре в корзине
            $stmt = $pdo->prepare("
                SELECT quantity, product_id 
                FROM cart 
                WHERE id = ? AND user_id = ?
            ");
            $stmt->execute([$cartId, $userId]);
            $cartItem = $stmt->fetch();

            if ($cartItem) {
                $newQuantity = $cartItem['quantity'] - $quantityToRemove;

                if ($newQuantity > 0) {
                    // Уменьшаем количество
                    $stmt = $pdo->prepare("UPDATE cart SET quantity = ? WHERE id = ?");
                    $stmt->execute([$newQuantity, $cartId]);
                } else {
                    // Удаляем запись полностью
                    $stmt = $pdo->prepare("DELETE FROM cart WHERE id = ?");
                    $stmt->execute([$cartId]);
                }

                // Возвращаем товар на склад
                $stmt = $pdo->prepare("UPDATE products SET stock = stock + ? WHERE id = ?");
                $stmt->execute([$quantityToRemove, $cartItem['product_id']]);
            }

            $pdo->commit();
        } catch (Exception $e) {
            $pdo->rollBack();
            $_SESSION['error'] = "Ошибка при удалении товара: " . $e->getMessage();
        }
    }
    header('Location: cart.php');
    exit;
}

// Создание заказа
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_order'])) {
    try {
        $pdo->beginTransaction();

        // Создаем заказ
        $stmt = $pdo->prepare("
            INSERT INTO orders (user_id, total, status, created_at) 
            VALUES (:user_id, :total, 'pending', CURRENT_TIMESTAMP)
        ");
        $stmt->execute([
            'user_id' => $userId,
            'total' => $total
        ]);
        $orderId = $pdo->lastInsertId();

        // Добавляем товары в заказ
        foreach ($cartItems as $item) {
            $stmt = $pdo->prepare("
                INSERT INTO order_items (order_id, product_id, quantity, price) 
                VALUES (:order_id, :product_id, :quantity, :price)
            ");
            $stmt->execute([
                'order_id' => $orderId,
                'product_id' => $item['product_id'],
                'quantity' => $item['quantity'],
                'price' => $item['discounted_price']
            ]);
        }

        // Очищаем корзину
        $stmt = $pdo->prepare("DELETE FROM cart WHERE user_id = :user_id");
        $stmt->execute(['user_id' => $userId]);

        $pdo->commit();
        header('Location: php/orders.php');
        exit;
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error'] = "Ошибка при создании заказа: " . $e->getMessage();
        header('Location: cart.php');
        exit;
    }
}
ob_end_flush();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Корзина</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <style>
        .discounted-price {
            color: #dc3545;
            font-weight: bold;
        }
        .original-price {
            text-decoration: line-through;
            color: #6c757d;
        }
    </style>
</head>
<body>
<?php include 'php/header.php'; ?>

<?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger"><?= $_SESSION['error'] ?></div>
    <?php unset($_SESSION['error']); ?>
<?php endif; ?>

<section class="cart py-5">
    <div class="container">
        <h1 class="text-center mb-4">Корзина</h1>

        <?php if (count($cartItems) > 0): ?>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>Товар</th>
                            <th>Цена</th>
                            <th>Количество</th>
                            <th>Сумма</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cartItems as $item): ?>
                        <tr>
                            <td class="align-middle">
                                <div class="d-flex align-items-center flex-wrap">
                                    <img src="<?= htmlspecialchars($item['image']) ?>"
                                         alt="<?= htmlspecialchars($item['name']) ?>"
                                         class="img-thumbnail me-3"
                                         style="width: 60px; height: 60px; object-fit: cover;">
                                    <div>
                                        <?= htmlspecialchars($item['name']) ?>
                                        <?php if ($item['discount_percent'] > 0): ?>
                                            <span class="badge bg-danger ms-2">-<?= $item['discount_percent'] ?>%</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td class="align-middle">
                                <?php if ($item['discount_percent'] > 0): ?>
                                    <span class="discounted-price"><?= number_format($item['discounted_price'], 2, '.', ' ') ?> руб.</span><br>
                                    <span class="original-price"><?= number_format($item['price'], 2, '.', ' ') ?> руб.</span>
                                <?php else: ?>
                                    <?= number_format($item['price'], 2, '.', ' ') ?> руб.
                                <?php endif; ?>
                            </td>
                            <td class="align-middle"><?= $item['quantity'] ?></td>
                            <td class="align-middle">
                                <?php if ($item['discount_percent'] > 0): ?>
                                    <span class="discounted-price"><?= number_format($item['total_price'], 2, '.', ' ') ?> руб.</span><br>
                                    <span class="original-price"><?= number_format($item['total_original_price'], 2, '.', ' ') ?> руб.</span>
                                <?php else: ?>
                                    <?= number_format($item['total_original_price'], 2, '.', ' ') ?> руб.
                                <?php endif; ?>
                            </td>
                            <td class="align-middle">
                                <form method="POST" class="d-flex">
                                    <input type="hidden" name="cart_id" value="<?= $item['cart_id'] ?>">
                                    <input type="number" name="delete_quantity"
                                           min="1" max="<?= $item['quantity'] ?>"
                                           value="1" class="form-control me-2" style="width: 70px;">
                                    <button type="submit" name="delete_item" class="btn btn-danger">Удалить</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot class="table-group-divider">
                        <tr>
                            <th colspan="3" class="text-end">Итого без скидки:</th>
                            <th><?= number_format($total + $totalDiscount, 2, '.', ' ') ?> руб.</th>
                            <td></td>
                        </tr>
                        <tr>
                            <th colspan="3" class="text-end">Скидка:</th>
                            <th class="text-danger">-<?= number_format($totalDiscount, 2, '.', ' ') ?> руб.</th>
                            <td></td>
                        </tr>
                        <tr>
                            <th colspan="3" class="text-end">Итого к оплате:</th>
                            <th class="fs-5"><?= number_format($total, 2, '.', ' ') ?> руб.</th>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
            </div>

            <div class="text-center mt-4">
                <form method="POST">
                    <button type="submit" name="create_order" class="btn btn-success btn-lg px-5 py-3">
                        Оформить заказ
                    </button>
                </form>
            </div>
        <?php else: ?>
            <div class="text-center py-5">
                <h4 class="text-muted mb-4">Ваша корзина пуста</h4>
                <a href="magazin.php" class="btn btn-primary">Перейти в каталог</a>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php include 'php/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const toggle = document.querySelector(".navbar-toggler");
        const menu = document.querySelector("#navbarNavDropdown");
        if (toggle && menu) {
            toggle.addEventListener("click", function () {
                const bsCollapse = new bootstrap.Collapse(menu, {
                    toggle: false
                });
                if (menu.classList.contains("show")) {
                    bsCollapse.hide();
                } else {
                    bsCollapse.show();
                }
            });
        }
    });
</script>
</body>
</html>
